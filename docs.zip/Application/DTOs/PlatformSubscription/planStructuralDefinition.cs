public class PlanStructuralDefinitionDto
{
    public string PlanName { get; set; }
    public int CategoryID { get; set; }
    public string TenantCategory { get; set; } // End User / Distributor / Reseller
    public int CurrencyId { get; set; }
    public string SettlementCurrency { get; set; }
    public string BillingInterval { get; set; } // Monthly, Quarterly, Yearly
    public string ContractValidity { get; set; } // e.g., "1 Year"
    public PricingModelType PricingModel { get; set; }
}
